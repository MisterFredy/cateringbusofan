/**
 * PresensiController
 *
 * @description :: Server-side logic for managing presensis
 * @help        :: See http://sailsjs.org/#!/documentation/concepts/Controllers
 */

module.exports = {
	
};

