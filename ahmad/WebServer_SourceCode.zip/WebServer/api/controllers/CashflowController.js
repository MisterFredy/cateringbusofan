/**
 * CashflowController
 *
 * @description :: Server-side logic for managing cashflows
 * @help        :: See http://sailsjs.org/#!/documentation/concepts/Controllers
 */

module.exports = {
	
};

